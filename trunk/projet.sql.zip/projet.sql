-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 27 Janvier 2010 à 15:38
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.4-2ubuntu5.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `binome`
--

CREATE TABLE IF NOT EXISTS `binome` (
  `num` int(4) NOT NULL auto_increment,
  `nom1` varchar(50) NOT NULL,
  `nom2` varchar(50) NOT NULL,
  `valide` int(1) default '0',
  `id_proj` int(4) default NULL,
  `niveau` varchar(2) NOT NULL,
  PRIMARY KEY  (`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `binome`
--

INSERT INTO `binome` (`num`, `nom1`, `nom2`, `valide`, `id_proj`, `niveau`) VALUES
(2, 'henel', 'brochot', 1, 13, 'AS'),
(3, 'beillas', 'höhm', 1, 8, 'AS'),
(4, 'lapierre', 'olivero', 1, 16, 'AS'),
(5, 'arjo', 'gres', 1, 11, 'AS'),
(7, 'veroudart', 'guedj', 1, 17, 'AS'),
(9, 'chauvin', 'giraudeau', 1, 7, 'AS'),
(10, 'rebaubier', '', 1, 0, 'AS'),
(11, 'jaumel', 'fagnou', 1, 15, 'AS');

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

CREATE TABLE IF NOT EXISTS `date` (
  `annee` int(4) NOT NULL,
  `construction_binome` int(20) NOT NULL,
  `enregistrement_projet` int(20) NOT NULL,
  `reunion_coor` int(20) NOT NULL,
  `diffusion_sujet` int(20) NOT NULL,
  `formulation_voeux` int(20) NOT NULL,
  `affectation_sujet` int(20) NOT NULL,
  `rapport_pre` int(20) NOT NULL,
  `remise_rapport` int(20) NOT NULL,
  `deb_soutenance` int(20) NOT NULL,
  `fin_soutenance` int(20) NOT NULL,
  `niveau` varchar(2) NOT NULL,
  `soutenance_etranger` int(20) NOT NULL,
  PRIMARY KEY  (`annee`,`niveau`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `date`
--

INSERT INTO `date` (`annee`, `construction_binome`, `enregistrement_projet`, `reunion_coor`, `diffusion_sujet`, `formulation_voeux`, `affectation_sujet`, `rapport_pre`, `remise_rapport`, `deb_soutenance`, `fin_soutenance`, `niveau`, `soutenance_etranger`) VALUES
(2009, 1232445660, 1240311720, 1232629380, 1232719440, 1232809500, 1232899560, 1232989620, 1233079680, 1233169740, 1233259800, 'LP', 0),
(2010, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1265068800, 1265320800, 'A2', 1296518400),
(2010, 1264460340, 1264028340, 1264114740, 1264201140, 1264503600, 1264460340, 1266879540, 1276250400, 1276552800, 1276725540, 'AS', 1293840000);

-- --------------------------------------------------------

--
-- Structure de la table `eleves`
--

CREATE TABLE IF NOT EXISTS `eleves` (
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `groupe` varchar(2) NOT NULL,
  `login` varchar(30) NOT NULL,
  `pwd` varchar(80) NOT NULL,
  `boolbin` varchar(1) NOT NULL default '0',
  `niveau` varchar(10) NOT NULL,
  PRIMARY KEY  (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `eleves`
--

INSERT INTO `eleves` (`nom`, `prenom`, `groupe`, `login`, `pwd`, `boolbin`, `niveau`) VALUES
('ABRIC', 'ARMAND', 'Q3', 'abric', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('AFFOUARD', 'ANTOINE', 'A', 'affouard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('ALESSIO', 'Jonathan', 'Q3', 'alessio', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ALTASSERRE', 'Olivier', 'Q2', 'altasserre', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('AMOUROUX', 'Jonathan', 'Q3', 'amouroux', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('ANDRIANASOLOARIJAONA', 'Yann', 'Q4', 'andrianasoloarijaona', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ARJO', 'MATHILDE', 'A', 'arjo', '40b404609fda3217aff5a03a91547e33', '1', 'AS'),
('AUBRY', 'ALINE', 'A', 'aubry', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('AUDOUX', 'Jérôme', 'Q1', 'audoux', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('AWUVE', 'Edem', 'Q1', 'awuve', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('BARCELO', 'Fabrice', 'Q1', 'barcelo', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BARDY', 'Catheline', 'Q2', 'bardy', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BARREAU', 'Anthony', 'Q1', 'barreau', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('BEILLAS', 'XAVIER', 'A', 'beillas', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('BELIN', 'Thibaud', 'Q2', 'belin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BENOITS', 'TOMMY', 'A', 'benoits', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('BERARD', 'Maxime', 'Q4', 'berard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERENGER', 'Charlotte', 'Q3', 'berenger', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERGERE', 'Robin', 'Q2', 'bergere', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERTRAND', 'Sébastien', 'Q2', 'bertrand', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOLLINI', 'Kévin', 'Q3', 'bollini', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOUDJOUHALI', 'Sofiane', 'Q3', 'boudjouhali', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOUTONNET', 'AMELIE', 'A', 'boutonnet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('BOUYS', 'ADRIAN', 'A', 'bouys', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('BRASSEUR', 'Julien', 'Q4', 'brasseur', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BRETON', 'JIM', 'A', 'breton', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('BRIVAL', 'Stéphan', 'Q1', 'brival', 'f02368945726d5fc2a14eb576f7276c0', '1', 'A2'),
('BROCHOT', 'ROMAIN', 'A', 'brochot', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('CABANE', 'Emmanuel', 'Q2', 'cabanee', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CABANE', 'Guillaume', 'Q1', 'cabaneg', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CAMROUX', 'KEVIN', 'A', 'camroux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CERAT', 'Nicolas', 'Q2', 'cerat', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CHAPPERT ', 'NICOLAS', 'A', 'chappert ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CHARMASSON', 'EMILIEN', 'A', 'charmasson', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CHAUVIN', 'COLINE', 'A', 'chauvin', '268b1511e154f84ebdb11492e086b0f1', '1', 'AS'),
('CHENAUX', 'Damien', 'Q3', 'chenaux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CIECIERSKI', 'CINDY', 'A', 'ciecierski', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('CIECKO', 'THOMAS', 'A', 'ciecko', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('CLAVEL', 'ARMAND', 'A', 'clavel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('COIGNET', 'Benjamin', 'Q3', 'coignet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CORNU ', 'Muriel', 'Q2', 'cornu ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CORREAUD', 'Sébastien', 'Q2', 'correaud', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CREMONESE', 'Yohann', 'Q3', 'cremonese', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CRINIER', 'ETIENNE', 'A', 'crinier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('DALVERNY', 'Romain', 'Q4', 'dalverny', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DARPHIN', 'Julien', 'Q4', 'darphin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DECOME ', 'FABRICE', 'A', 'decome ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('DEFAY', 'Yannick', 'Q4', 'defay', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DELACROIX', 'Christophe', 'Q1', 'delacroix', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DESHOULLIERS', 'Jonathan', 'Q1', 'deshoulliers', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DUBOIS', 'LUCIEN', 'A', 'dubois', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('DUFER', 'BENJAMIN', 'A', 'dufer', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('DUGAST', 'Fabien', 'Q3', 'dugast', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DUMONT', 'GAËTAN', 'A', 'dumont', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('El AMRANI', 'Ayoub', 'Q1', 'el amrani', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('EL MOKADDEM', 'MAROUAN', 'A', 'el mokaddem', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('ESCUDERO', 'Loïc', 'Q4', 'escudero', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ESPOSITO', 'Claudia', 'Q4', 'esposito', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ESTEBE ', 'ANTHONY', 'A', 'estebe ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FAGNOU', 'AURORE', 'A', 'fagnou', 'db952976dbf44ccc0df9116ca7158077', '1', 'AS'),
('FAROK', 'MY DRISS', 'A', 'farok', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('FATTAL', 'Thomas', 'Q2', 'fattal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FAURE', 'MATHIEU', 'A', 'faure', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('FAUVEL-JAEGER', 'Thomas', 'Q2', 'fauvel-jaeger', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FIORENTINO', 'PAUL-ALAIN', 'A', 'fiorentino', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('FLOCH', 'SEBASTIEN', 'A', 'floch', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FONQUERNIE', 'YVES', 'A', 'fonquernie', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FORGO', 'NATHALIE', 'A', 'forgo', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('FOURNIER', 'Fanny', 'Q3', 'fournier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FROMAGER', 'Arnaud', 'Q3', 'fromager', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GAILLARD', 'Flavien', 'Q3', 'gaillard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GANZA', 'Yvan', 'Q3', 'ganza', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GARCIA', 'GUILLAUME', 'A', 'garcia', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('GELY', 'Mélanie', 'Q4', 'gely', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GENIEYS', 'Irvin', 'Q4', 'genieys', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GIRAUDEAU', 'EDDY', 'A', 'giraudeau', '536456dda828fc54499d4de657834096', '1', 'AS'),
('GOT', 'ALEXANDRE', 'A', 'got', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('GR?S', 'J?R?MY', 'A', 'gr?s', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('GRAZIOLI', 'ALEXANDRE', 'A', 'grazioli', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('GUARRERA', 'Adrian', 'Q1', 'guarrera', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GUEDJ', 'BENJAMIN', 'A', 'guedj', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('HADJOUR', 'Rachid', 'Q2', 'hadjour', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('HAENEL', 'CAMILLE', 'A', 'haenel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('HENEL', 'MAÏNA', 'A', 'henel', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('HERMET', 'FREDERIC', 'A', 'hermet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('HOLTZ', 'Sven', 'Q3', 'holtz', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('HÖHM', 'JULIEN', 'A', 'höhm', 'bc29cb2f1821e7e1cf4c078d14f21e9d', '1', 'AS'),
('JANSSEN', 'Colas', 'Q2', 'janssen', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('JAUMEL', 'TIMOTH?E', 'A', 'jaumel', '39e8c1e6c99a9f30b2d282e5180b96d8', '1', 'AS'),
('KUHN', 'Alexandre', 'Q4', 'kuhn', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LABLANCHY', 'Sébastien', 'Q4', 'lablanchy', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LABORDE', 'Fabien', 'Q1', 'laborde', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LANDA', 'KEVIN', 'A', 'landa', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('LAPIERRE', 'OLIVIER', 'A', 'lapierre', 'f02368945726d5fc2a14eb576f7276c0', '1', 'AS'),
('LAUZE ', 'Matthieu', 'Q3', 'lauze ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LE FRIOUX', 'YANN', 'A', 'le frioux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('LEPICARD', 'DAVID', 'A', 'lepicard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('LOUCIF', 'Cyril', 'Q1', 'loucif', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAILLE', 'Nicolas', 'Q1', 'maille', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MANIACI', 'Stéphane', 'Q1', 'maniaci', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MASSE', 'Cédric', 'Q2', 'masse', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MATHERON', 'Charlotte', 'Q2', 'matheron', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MATUSZEK', 'Guillaume', 'Q4', 'matuszek', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAURICE', 'Céline', 'Q1', 'maurice', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAURY', 'Marc', 'Q1', 'maury', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MELIA', 'Geoffrey', 'Q4', 'melia', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MIRON', 'Jordan', 'Q3', 'miron', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MONNIER', 'Dorian', 'Q1', 'monnier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MORAINE', 'MAXIME', 'A', 'moraine', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('MORENO', 'PIERRE', 'A', 'moreno', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('MOUMINOUX', 'Guillaume', 'Q2', 'mouminoux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('NABHEEBUCUS', 'Shehzaad', 'Q1', 'nabheebucus', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('NICOLACCINI', 'Mickaël', 'Q3', 'nicolaccini', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('OLIVERO', 'FLORIAN', 'A', 'olivero', 'f59f4b75f3e3cf221d368c19cbe0da60', '1', 'AS'),
('OUALI', 'Samy', 'Q4', 'ouali', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PAPIN', 'Geoffrey', 'Q1', 'papin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PARRA', 'Loïc', 'Q1', 'parra', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PASCAL', 'Geoffrey', 'Q4', 'pascal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PASTORELLI', 'GHISLAIN', 'A', 'pastorelli', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('PASTRE', 'Emerentienne', 'Q3', 'pastre', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PEREZ ', 'OLIVIER', 'A', 'perez ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('PERRIN', 'EVIAN', 'A', 'perrin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('PERROT', 'Grégoire', 'Q2', 'perrot', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('POLDER', 'Guillaume', 'Q1', 'polder', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PORTALES', 'Robin', 'Q2', 'portales', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('POURCINE', 'Nicolas', 'Q4', 'pourcine', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PROUVOT', 'Vivien', 'Q4', 'prouvot', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PRUDHOMME', 'Gaël', 'Q2', 'prudhomme', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUECH', 'Robin', 'Q2', 'puech', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUGINIER', 'Julien', 'Q3', 'puginier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUGLIESE', 'Yann', 'Q2', 'pugliese', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUIGCERVER', 'ELSA', 'A', 'puigcerver', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('QUETTIER', 'LUCILE', 'A', 'quettier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('RABATEL', 'Camille', 'Q1', 'rabatel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RACLET', 'Yoann', 'Q4', 'raclet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RAMI', 'LEÏLA', 'A', 'rami', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('REBAUBIER', 'WILLIAM', 'A', 'rebaubier', 'ac754a330530832ba1bf7687f577da91', '1', 'AS'),
('REGAZZONI', 'ANTHONY', 'A', 'regazzoni', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('ROBERT', 'Kevin', 'Q2', 'robert', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ROLANDO', 'Mathilde', 'Q4', 'rolando', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ROUQUETTE', 'Thibaut', 'Q2', 'rouquette', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RUBAGOTTI', 'AURELIEN', 'A', 'rubagotti', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('S?N?CAL ', 'GAËL', 'A', 's?n?cal ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('SABACHVILI', 'David', 'Q2', 'sabachvili', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SABATIER', 'PIERRE-ALAIN', 'Q1', 'sabatier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SALEIL', 'Baptiste', 'Q1', 'saleil', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SANICHANH', 'Morgan', 'Q3', 'sanichanh', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SAUVET', 'Matthieu', 'Q2', 'sauvet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SCHMITT', 'Clément', 'Q3', 'schmitt', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SCHNEIDER', 'AUDREY', 'A', 'schneider', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('SEGUIN', 'TRISTAN', 'A', 'seguin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('SENDNER', 'Damien', 'Q4', 'sendner', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SENDRA', 'Anthony', 'Q4', 'sendra', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SENN', 'GAELLE', 'A', 'senn', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('SIMONNET', 'VALERIE', 'A', 'simonnet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('SIRACUSA', 'LILIAN', 'A', 'siracusa', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('TCHERTCHIAN', 'Guillaume', 'Q2', 'tchertchian', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TEIXEIRA', 'Julien', 'Q3', 'teixeira', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('THIBAUD', 'Henri', 'Q2', 'thibaud', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TIRARD', 'Floriane', 'Q2', 'tirard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TREMESAYGUES', 'Jonathan', 'Q3', 'tremesaygues', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TUDESQ', 'Philippe', 'Q4', 'tudesq', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VALENTIN', 'FABIEN', 'A', 'valentin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VAQUER', 'Paul', 'Q4', 'vaquer', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VEDEL', 'CHRISTOPHE', 'A', 'vedel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VERBAL', 'CHRISTOPHER', 'A', 'verbal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VERGNES ', 'PASCAL', 'A', 'vergnes ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('VEROUDART', 'LOÏC', 'A', 'veroudart', 'b994002d008ad3d25006149aeb962164', '1', 'AS'),
('VERSTRAETE', 'Didier', 'Q4', 'verstraete', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VICAIRE ', 'HENRI HARALD', 'A', 'vicaire ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VILACA', 'ADRIEN', 'A', 'vilaca', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('VILLAGE', 'Benoît', 'Q4', 'village', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VINARD', 'Florian', 'Q3', 'vinard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('WEGSCHEIDER', 'Bastien', 'Q1', 'wegscheider', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ZIMMERMANN', 'Denis', 'Q3', 'zimmermann', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2');

-- --------------------------------------------------------

--
-- Structure de la table `indisponibilite`
--

CREATE TABLE IF NOT EXISTS `indisponibilite` (
  `login` varchar(30) NOT NULL,
  `lundi` varchar(50) NOT NULL,
  `mardi` varchar(50) NOT NULL,
  `mercredi` varchar(50) NOT NULL,
  `jeudi` varchar(50) NOT NULL,
  `vendredi` varchar(50) NOT NULL,
  PRIMARY KEY  (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `indisponibilite`
--

INSERT INTO `indisponibilite` (`login`, `lundi`, `mardi`, `mercredi`, `jeudi`, `vendredi`) VALUES
('bellahsene', ';', ';', ';', ';', ';'),
('berlinet', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;'),
('betaille', ';1;2;9;10;11;', ';1;2;9;10;11;', ';1;2;9;10;11;', ';1;2;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;'),
('chapellier', ';1;2;3;4;5;6;7;8;9;10;11;', ';10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;'),
('chirouze', ';', ';1;2;3;4;5;6;7;8;', ';1;2;3;4;5;6;7;8;9;10;11;', ';', ';'),
('cogis', ';', ';6;7;8;', ';7;8;9;', ';', ';'),
('coletta', ';', ';1;2;', ';7;8;9;', ';1;2;8;9;10;11;', ';8;9;10;11;'),
('croitoru', ';1;2;3;4;5;6;', ';1;2;3;4;5;6;', ';1;', ';1;', ';1;2;3;4;5;6;'),
('eggrickx', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;', ';'),
('joannides', ';', ';', ';6;7;8;', ';', ';'),
('joubert', ';', ';1;2;3;', ';', ';1;2;3;4;5;', ';3;4;5;6;7;8;'),
('marie-jeanne', ';', ';1;2;3;7;8;9;10;', ';1;2;3;4;5;8;9;10;', ';1;3;4;5;8;9;10;', ';1;2;3;4;5;8;9;'),
('mazars', ';6;7;8;9;10;11;', ';', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;', ';'),
('metz', ';', ';1;2;3;4;10;11;', ';', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;'),
('michel', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';', ';1;2;3;4;5;6;7;8;9;10;11;'),
('nouguier', ';', ';5;6;11;', ';5;6;11;', ';5;6;11;', ';1;2;3;4;5;6;7;8;9;10;11;'),
('pallejan', ';', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;8;9;10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';'),
('pallejax', ';', ';2;3;4;5;8;9;10;', ';1;2;3;4;5;6;7;8;9;10;11;', ';', ';'),
('sabatier', ';', ';6;7;', ';', ';3;4;5;', ';'),
('salmon', ';10;11;', ';5;6;7;10;11;', ';10;11;', ';10;11;', ';10;11;'),
('simonet', ';', ';8;9;', ';', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;'),
('valverde', ';', ';10;11;', ';1;2;3;4;5;6;7;8;9;10;11;', ';1;2;3;', ';1;2;3;4;5;6;7;8;9;10;11;');

-- --------------------------------------------------------

--
-- Structure de la table `planning`
--

CREATE TABLE IF NOT EXISTS `planning` (
  `id` int(11) NOT NULL auto_increment,
  `lib` text NOT NULL,
  `date_fin` timestamp NOT NULL default '0000-00-00 00:00:00',
  `niveau` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `planning`
--


-- --------------------------------------------------------

--
-- Structure de la table `prof`
--

CREATE TABLE IF NOT EXISTS `prof` (
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `login` varchar(30) NOT NULL,
  `pwd` varchar(80) NOT NULL,
  `droit` int(1) NOT NULL default '0',
  PRIMARY KEY  (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prof`
--

INSERT INTO `prof` (`nom`, `prenom`, `login`, `pwd`, `droit`) VALUES
('ALBERNHE-GIORDAN', 'Hugette', 'albernhe', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('ARTIGNAN', 'Guillaume', 'artignan', '354cfa2e98a3d2738417677714b64332', 0),
('BELLAHSENE', 'Zohra', 'bellahsene', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BERLINET', 'Alain', 'berlinet', '03f050d1c60df30061bd6cb09ed40083', 0),
('BETAILLE', 'Henri', 'betaille', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BONACHE', 'Adrien', 'bonache', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BOYAT', 'Jeannine', 'boyat', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('CHAPELLIER', 'Philippe', 'chapellier', '529361eade16798a865592457bd31a30', 0),
('CHIROUZE', 'Anne', 'chirouze', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('COGIS', 'Olivier', 'cogis', '95011b79a4773b86b2c06221f513c6b2', 0),
('COLETTA', 'Rémi', 'coletta', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('CROITORU', 'Madalina', 'croitoru', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('DELPERDANGE', 'Catherine', 'delperdange', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('EGGRICKX', 'Ariel', 'eggrickx', '34f8f31fa37aeb995cbed5d82bbffa8d', 0),
('GARCIA', 'Francis', 'garcia', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('GENTHIAL', 'Michèle', 'genthial', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('GOUAICH', 'Adbelkader', 'gouaich', 'eb970203d64f5491267a22dfef93037c', 0),
('GUILLEMENET', 'Yoann', 'guillemenet', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('JOANNIDES', 'Marc', 'joannides', '180fd182f9a0742f483619781ccc36c4', 0),
('JOUBERT', 'Alain', 'joubert', 'd5b44dadd25d5d32c524b8a59ef46153', 0),
('LACHENY', 'Alain', 'lacheny', '508aabef6aa1190d26b88c7174c9a997', 0),
('LIBRES', 'Aline', 'libres', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('MAHE', 'Serge-André', 'mahe', '268b3a34a9c9b812ce8431d12592caaf', 0),
('MARIE-JEANNE', 'Alain', 'marie-jeanne', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('MAZARS-CHAPELON', 'Agnès', 'mazars', '909c22f77ab388fd10c7eb96d0e8772e', 0),
('METZ', 'Stéphanie', 'metz', '36f89ebc0885d432ba842f9ca2f41968', 0),
('MICHEL', 'Fabien', 'michel', 'db53cc3598bf0a3a782ad5706ff82158', 0),
('NOUGUIER', 'Bernard', 'nouguier', '8ecad5b7ca62b6173086362381559a11', 0),
('PALAYSI', 'Jérôme', 'palaysi', '9df122bb54b3f964895943066d41ab27', 0),
('PALLEJA', 'Nathalie', 'pallejaN', 'abeb4ec8bd286880b9410fc5cd916e84', 0),
('PALLEJA', 'Xavier', 'pallejaX', 'c5558d6d72ccc2f9016e50039243d8f8', 0),
('SABATIER', 'Alain', 'sabatier', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('SALMON', 'Laurence', 'salmon', '21232f297a57a5a743894a0e4a801fc3', 1),
('SIMONET', 'Geneviève', 'simonet', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('VALVERDE', 'Irène', 'valverde', 'b2688812ffc5952c7ad57c95223f023d', 0);

-- --------------------------------------------------------

--
-- Structure de la table `projets`
--

CREATE TABLE IF NOT EXISTS `projets` (
  `id_proj` int(4) NOT NULL auto_increment,
  `tuteur1` varchar(60) NOT NULL,
  `tuteur2` varchar(60) NOT NULL,
  `titre` varchar(100) NOT NULL,
  `binwish` int(1) NOT NULL,
  `binpos` int(1) NOT NULL,
  `description` text NOT NULL,
  `qualif` varchar(100) NOT NULL,
  `dom_appl` text NOT NULL,
  `mat_log` varchar(200) NOT NULL,
  `remarques` text NOT NULL,
  `niveau` varchar(10) NOT NULL,
  `groupe` text NOT NULL,
  PRIMARY KEY  (`id_proj`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `projets`
--

INSERT INTO `projets` (`id_proj`, `tuteur1`, `tuteur2`, `titre`, `binwish`, `binpos`, `description`, `qualif`, `dom_appl`, `mat_log`, `remarques`, `niveau`, `groupe`) VALUES
(1, 'salmon', '', 'intranet de la gestion des projets au dpt Info', 1, 1, 'Etude de la sécurité de ce logiciel.\r\nEdition de liste papier des tables essentielles de la BD', ' développement & programmation', 'Intranet', 'PHP,Java scrip, MySql', 'suite d\\''un projet A2', 'AS', ''),
(3, 'lacheny', '', 'site web d\\''échanges sur internet pour collectionneurs', 1, 2, 'Le but de ce projet est de concevoir un site web permettant des échanges entre collectionneurs', ' analyse & conception, travail original', 'Analyse\r\nBases de données', 'Logiciels libres (PHP, MySQL, …)', 'Ce site sera plus spécialement dédié à un thème choisi par les étudiants (timbres, CD, DVD, …)', 'AS', ''),
(4, 'lacheny', '', 'Conception d\\''un gestionnaire de tests à choix multiples sur le web (quizz)', 1, 1, 'Le but de ce projet est de construire un gestionnaire de questionnaires à choix multiples consultables avec d\\''un navigateur web.\r\n1) logiciel permettant de créer et modifier des questionnaires (mode administrateur)\r\n2) logiciel d\\''utilisation après identification de questionnaires (mode utilisateur)', ' analyse & conception, développement & programmation, travail original', 'Analyse\r\nBases de données\r\nProgrammation', 'logiciels libres (PHP, MySQL, … )', 'Le gestionnaire devra pouvoir inclure des documents multi média (images, sons, …).', 'AS', ''),
(6, 'joubert', '', 'Détermination des différents sens d\\''un terme dans un réseau lexical', 1, 1, 'Un réseau lexical se présente sous forme d\\''un graphe constitué d\\''un ensemble de termes (mots simples ou mots composés) reliés entre eux par des relations.\r\nEx.: sapin-arbre, sapin-montagne, sapin-Noël, sapin-guirlande, mais également: arbre-montagne, Noël-guirlande.\r\nIl est possible de regrouper les termes reliés à un même terme (ex: sapin) en plusieurs groupes (appelés cliques). Chaque clique correspond à un sens (ex: sapin en tant qu\\''arbre, ou sapin de Noël).\r\nDans ce projet, il s\\''agira d\\''écrire un logiciel qui, à partir d\\''un réseau lexical déjà existant, permettra pour un terme donné d\\''en déterminer les cliques. Les données seront fournies sous forme d\\''une matrice; les indices de la matrice correspondent aux différents termes; ainsi mat[i,j] correspond à la relation entre les termes i et j. Une clique du terme T est constituée d\\''un esemble de termes, tous reliés à T et tous reliés entre eux.', ' analyse & conception, développement & programmation, travail original', 'Programmation (pour le Traitement Automatique du Langage Naturel)', 'PC\r\nLangage à définir', 'Projet en relation avec l\\''équipe TAL du LIRMM\r\nAllergiques à la Programmation s\\''abstenir.', 'AS', ''),
(7, 'chapellier', 'garcia', 'Réalisation d’un logiciel de comptabilité générale ', 2, 2, 'Le projet consiste en la réalisation d’un logiciel de comptabilité générale permettant de saisir une balance de départ et d’enregistrer les écritures de la période dans le journal. Il utilisera ces données pour la réalisation du compte de résultat et du bilan. Il sera en outre possible à tout moment : \r\n- de connaître la situation d’un compte (grand livre)\r\n- de visualiser la balance à jour\r\n- de sauvegarder le travail réalisé\r\n- d’imprimer\r\n', ' analyse & conception', 'Comptabilité, analyse, programmation', '', 'Aucune', 'AS', ''),
(8, 'lacheny', '', 'Site web de vente de livres anciens', 1, 1, 'Conception d\\''un site web de vente en ligne de livres anciens (bouquiniste) avec intégration de l\\''application \\"Paypal\\"', ' analyse & conception, développement & programmation, travail original', 'Génie logiciel\r\nBases de données\r\nDéveloppement web', 'logiciels libres (postgreSQL, PHP, ...)', 'Aucune', 'AS', ''),
(9, 'palaysi', '', 'Système d\\''information pour le suivi d\\''élèves à l\\''école primaire', 1, 2, 'Il s\\''agit de développer un système d\\''information et une interface WEB permettant à un enseignant du primaire de suivre l\\''acquisition des compétences de ses écoliers. Ce sujet est plutôt orienté sur la modélisation du système d\\''information (la base de données).\r\n\r\nA l\\''école élémentaire il existe des niveaux : CM2, CM1, CE2, CE1, CP\r\nUne classe est faite de 1 à plusieurs niveaux.\r\nUne classe a un professeur (ce professeur enseigne toutes les matières).\r\n\r\nLes compétences visées (une liste est donnée par l\\'' Éducation Nationale) sont du genre :\r\n- écrire sans erreur des mots appris (CP)\r\n- connaître la table de multiplication par 2 (CP)\r\n- connaître (savoir écrire et nommer) les nombres entiers naturels inférieurs à 1000 (CE1)\r\n- ...\r\nIl en existe plusieurs dizaines.\r\n\r\nLe professeur devrait pouvoir noter chaque compétence pour chaque élève. Des pages spéciales devraient permettre par exemple :\r\n- de visualiser l\\''évolution d\\''un élève (ou d\\''un groupe) tout au long de l\\''année\r\n- de mettre en évidence les compétences qui restent à travailler pour un élève (ou un groupe) \r\n', ' analyse & conception, développement & programmation', '', 'UML, HTML, PHP, SQL', 'Aucune', 'AS', ''),
(10, 'palaysi', '', 'gestionnaire de photographies', 1, 1, 'On souhaite créer un site WEB où les utilisateurs pourraient enregistrer leurs photographies. Pour chacune de ses photos, l\\''utilisateur devrait pouvoir choisir de la partager ou non avec d\\''autres. Il devrait pouvoir rechercher dans ses photos celles qui ont été prise à un endroit donné ou à un moment donné ou encore celles dans lesquelles figurent des personnes en particulier. \r\nUn texte narratif pourrait être associé à une photo ou un groupe de photos. Chaque photo pourrait être classée dans un ou des dossiers. Enfin dans une version améliorée, il devrait être possible d\\''appliquer des filtres. ', ' analyse & conception, développement & programmation', '', 'UML, HTML, PHP, SQL, SVG (prolongement)', 'Aucune', 'AS', ''),
(11, 'michel', '', 'Programmation d\\''un jeu avec IA inspiré par le jeu de société pandémie', 1, 1, 'Ce projet concerne la programmation d\\''un jeu possédant une IA basée sur la programmation multi-agents (SMA). Il s\\''agira, en s\\''inspirant du jeu pandémie, de réaliser un jeu basé sur le même principe mais où certains joueurs pourront être joués par une IA. Le jeu sera programmé en Java à l\\''aide de la plate-forme MadKit/TurtleKit.', ' analyse & conception, développement & programmation, travail original', 'Jeu vidéo', 'Java, MadKit/TurtleKit', 'Aucune', 'AS', ''),
(13, 'GARCIA', 'chapellier', 'Application pour la gestion d\\''épreuves cyclistes', 1, 2, 'Le comité départemental de l\\''Hérault organise tous les ans la coupe Codech. L\\''objectif est d\\''établir un classement des clubs en fonction de leur participation aux différents évènements proposés.Il faudra analyser les besoins et concevoir une application de type web pour que les clubs puissent saisir , afficher et modifier les résultats des épreuves qu\\''ils organisent. IL faudra aussi réfléchir à la sécurité à mettre en oeuvre.', ' analyse & conception, développement & programmation', 'BAses de données, web', 'Php, mysql et autres ci nécessaire.', 'Aucune', 'AS', ''),
(14, 'GARCIA', 'chapellier', 'Comparateur de solutions de sauvegarde à distance', 1, 2, 'Un grand nombre de fournisseurs proposent des solutions de sauvegarde à distance. Chaque solution se caractérise par un grand nombre de fonctionnalités (débit nécessaire, capacité de stockage, prix de la solution, type de fichiers sauvegardés, condition de restauration, ...) Les utilisateurs sont souvent perdus lorsqu\\''ils envisagent d\\''en utiliser une. L\\''objectif est de créer une application qui référencera toutes les solutions commercialisées en France avec leur caractéristiques, de recherche celle qui correspond le mieux à un utilisateur donné à partir d\\''un recherche multicritères, de comparer techniquement 3 ou 4 solutions entre elles pour aider l\\''utilisateur à choisir.', ' analyse & conception, développement & programmation', 'Web et bases de données', 'php, mysql', 'Aucune', 'AS', ''),
(15, 'lacheny', '', 'site web consacré au volley-ball', 1, 1, 'Le site repose sur le principe d\\''agréger et diffuser des actualités sportives relatives au volley-ball en les stockant dans une base de données consultable par les internautes', ' analyse & conception, développement & programmation, travail original', 'Génie logiciel\r\nBases de données', 'logiciels libres : PHP, MySQL', 'Aucune', 'AS', ''),
(16, 'mahe', '', 'objets dynamiques', 1, 2, 'Les objets dynamiques sont d\\''abord programmés sous forme de maquette très simple à programmer: c\\''est unparcours total de séquence!\r\nEnsuite le binôme choisit une application de son choix, par exemple un jeu, un pilote d\\''écluse, un système d\\''arosage,...\r\nLe sujet peut ensuite évoluer soit avec de la programmation graphique, soit avec de la programmation système, soit avec de la programmation web en fonction des aptitudes et des goûts des étudiants.', ' analyse & conception, développement & programmation', 'Tous domaines d\\''application', 'Ceux du département et éventuellement d\\''autres', 'Aucune', 'AS', ''),
(17, 'mahe', '', 'Service urbain d\\''identité mobile', 1, 1, 'Une association d\\''usagers de téléphonie portable demande à ses adhérents de communiquer à un système leur position GPS afin de leur rendre service. Le système peut notamment réagir dans les deux situations suivantes:\r\n- lorsque deux adhérents qui souhaitent se rencontrer se trouvent à proximité, le système prend l\\''initiative de les piloter vers un lieu de rendez-vous.\r\n- lorsqu\\''un adhérent se trouve à proximité d\\''un adhérent qu\\''il ne souhaite pas rencontrer, le système prend l\\''initiative de le piloter afin d\\''éviter leur rencontre.\r\nLe projet consiste à étudier la mise en place d\\''une première version simplifiée d\\''un tel système. \r\n', ' analyse & conception, développement & programmation', 'téléphonie mobile, gestion de flotte', 'J2M2 wireless toolkit ou autres outils et langages', 'Aucune', 'AS', ''),
(18, 'mahe', '', 'objets complexes', 1, 2, 'Le projet consiste à programmer très simplement des objets décomposables en sous objets.\r\nOn donne ensuite un type à ces objets: file d\\''attente, pile, liste d\\''inscription,...\r\nCette programmation est ensuite appliquée à un exemple sur proposition des étudiants: génération de site web, modélisme, etc,... ', ' analyse & conception, développement & programmation', 'logiciel grand public', 'Ceux du département ou d\\''autres selon les préférences des étudiants', 'Aucune', 'AS', ''),
(19, 'chirouze', 'boyat', 'Application graphique: assistant  de classe', 1, 1, 'Il s\\''agit de développer une application graphique pour assister l\\''enseignant dans son cours. L\\''interface s\\''inspirera du plan physique de la classe (bureaux, horloge, armoire) et devra permettre de façon la plus intuitive possible de gérer le contenu du cours (accès aux documents, au plan du cours, au bilan du cours, à des outils tels que dés ou jeu de cartes)  et les étudiants (par un clic sur leur place, accès à leur profil: absences, notes, participation etc).\r\n', ' analyse & conception, développement & programmation, travail original', 'Programmation objet et graphisme', 'PC et JAVA', 'Aucune', 'AS', '');

-- --------------------------------------------------------

--
-- Structure de la table `soutenance`
--

CREATE TABLE IF NOT EXISTS `soutenance` (
  `id_bin` int(4) NOT NULL,
  `date` int(10) NOT NULL,
  `salle` int(3) NOT NULL,
  `tuteur_comp` varchar(30) NOT NULL,
  PRIMARY KEY  (`id_bin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `soutenance`
--

INSERT INTO `soutenance` (`id_bin`, `date`, `salle`, `tuteur_comp`) VALUES
(1, 1265094000, 123, 'albernhe'),
(18, 1265094000, 118, 'bellahsene'),
(19, 1265097600, 114, 'betaille');

-- --------------------------------------------------------

--
-- Structure de la table `wish`
--

CREATE TABLE IF NOT EXISTS `wish` (
  `id_bin` int(4) NOT NULL,
  `wish1` int(4) NOT NULL,
  `wish2` int(4) NOT NULL,
  `wish3` int(4) NOT NULL,
  `wish4` int(4) NOT NULL,
  `wish5` int(4) NOT NULL,
  `niveau` varchar(2) NOT NULL,
  PRIMARY KEY  (`id_bin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `wish`
--

INSERT INTO `wish` (`id_bin`, `wish1`, `wish2`, `wish3`, `wish4`, `wish5`, `niveau`) VALUES
(2, 13, 4, 15, 19, 9, 'AS'),
(3, 8, 3, 15, 19, 9, 'AS'),
(4, 16, 18, 6, 11, 1, 'AS'),
(5, 11, 10, 13, 14, 3, 'AS'),
(7, 17, 9, 19, 16, 18, 'AS'),
(9, 7, 9, 17, 6, 11, 'AS'),
(11, 15, 10, 19, 8, 3, 'AS'),
(12, 19, 17, 15, 13, 10, 'AS');
