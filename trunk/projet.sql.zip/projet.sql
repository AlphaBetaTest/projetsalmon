-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Dim 17 Janvier 2010 à 17:00
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `binome`
--

CREATE TABLE IF NOT EXISTS `binome` (
  `num` int(4) NOT NULL AUTO_INCREMENT,
  `nom1` varchar(50) NOT NULL,
  `nom2` varchar(50) NOT NULL,
  `valide` int(1) DEFAULT '0',
  `id_proj` int(4) DEFAULT NULL,
  `niveau` varchar(2) NOT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Contenu de la table `binome`
--

INSERT INTO `binome` (`num`, `nom1`, `nom2`, `valide`, `id_proj`, `niveau`) VALUES
(21, 'aubry', 'breton', 1, 1, 'LP');

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

CREATE TABLE IF NOT EXISTS `date` (
  `annee` int(4) NOT NULL,
  `construction_binome` int(20) NOT NULL,
  `enregistrement_projet` int(20) NOT NULL,
  `reunion_coor` int(20) NOT NULL,
  `diffusion_sujet` int(20) NOT NULL,
  `formulation_voeux` int(20) NOT NULL,
  `affectation_sujet` int(20) NOT NULL,
  `rapport_pre` int(20) NOT NULL,
  `remise_rapport` int(20) NOT NULL,
  `deb_soutenance` int(20) NOT NULL,
  `fin_soutenance` int(20) NOT NULL,
  `niveau` varchar(2) NOT NULL,
  `soutenance_etranger` int(20) NOT NULL,
  PRIMARY KEY (`annee`,`niveau`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `date`
--

INSERT INTO `date` (`annee`, `construction_binome`, `enregistrement_projet`, `reunion_coor`, `diffusion_sujet`, `formulation_voeux`, `affectation_sujet`, `rapport_pre`, `remise_rapport`, `deb_soutenance`, `fin_soutenance`, `niveau`, `soutenance_etranger`) VALUES
(2010, 1263945600, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 1262304000, 'A2', 1263168000),
(2010, 1265068800, 1265068800, 1267488000, 1270170000, 1304301540, 1275436800, 1278028800, 1280707200, 1263168000, 1285977600, 'LP', 1288656000);

-- --------------------------------------------------------

--
-- Structure de la table `eleves`
--

CREATE TABLE IF NOT EXISTS `eleves` (
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `groupe` varchar(2) NOT NULL,
  `login` varchar(30) NOT NULL,
  `pwd` varchar(80) NOT NULL,
  `boolbin` varchar(1) NOT NULL DEFAULT '0',
  `niveau` varchar(10) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `eleves`
--

INSERT INTO `eleves` (`nom`, `prenom`, `groupe`, `login`, `pwd`, `boolbin`, `niveau`) VALUES
('ABRIC', 'Armand', 'Q3', 'abric', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('AFFOUARD', 'ANTOINE', 'A', 'affouard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('ALESSIO', 'Jonathan', 'Q3', 'alessio', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ALTASSERRE', 'Olivier', 'Q2', 'altasserre', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('AMOUROUX', 'Jonathan', 'Q3', 'amouroux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ANDRIANASOLOARIJAONA', 'Yann', 'Q4', 'andrianasoloarijaona', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ARJO', 'MATHILDE', 'A', 'arjo', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('AUBRY', 'ALINE', 'A', 'aubry', 'f02368945726d5fc2a14eb576f7276c0', '1', 'LP_PGI'),
('AUDOUX', 'Jérôme', 'Q1', 'audoux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('AWUVE', 'Edem', 'Q1', 'awuve', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BARCELO', 'Fabrice', 'Q1', 'barcelo', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BARDY', 'Catheline', 'Q2', 'bardy', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BARREAU', 'Anthony', 'Q1', 'barreau', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BEILLAS', 'XAVIER', 'A', 'beillas', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('BELIN', 'Thibaud', 'Q2', 'belin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BENOITS', 'TOMMY', 'A', 'benoits', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('BERARD', 'Maxime', 'Q4', 'berard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERENGER', 'Charlotte', 'Q3', 'berenger', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERGERE', 'Robin', 'Q2', 'bergere', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BERTRAND', 'Sébastien', 'Q2', 'bertrand', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOLLINI', 'Kévin', 'Q3', 'bollini', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOUDJOUHALI', 'Sofiane', 'Q3', 'boudjouhali', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BOUTONNET', 'AMELIE', 'A', 'boutonnet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('BOUYS', 'ADRIAN', 'A', 'bouys', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('BRASSEUR', 'Julien', 'Q4', 'brasseur', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BRETON', 'JIM', 'A', 'breton', 'f02368945726d5fc2a14eb576f7276c0', '1', 'LP_PGI'),
('BRIVAL', 'Stéphan', 'Q1', 'brival', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('BROCHOT', 'ROMAIN', 'A', 'brochot', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('CABANE', 'Emmanuel', 'Q2', 'cabanee', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CABANE', 'Guillaume', 'Q1', 'cabaneg', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CAMROUX', 'KEVIN', 'A', 'camroux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CERAT', 'Nicolas', 'Q2', 'cerat', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CHAPPERT ', 'NICOLAS', 'A', 'chappert ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CHARMASSON', 'EMILIEN', 'A', 'charmasson', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('CHAUVIN', 'COLINE', 'A', 'chauvin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('CHENAUX', 'Damien', 'Q3', 'chenaux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CIECIERSKI', 'CINDY', 'A', 'ciecierski', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('CIECKO', 'THOMAS', 'A', 'ciecko', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('CLAVEL', 'ARMAND', 'A', 'clavel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('COIGNET', 'Benjamin', 'Q3', 'coignet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CORNU ', 'Muriel', 'Q2', 'cornu ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CORREAUD', 'Sébastien', 'Q2', 'correaud', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CREMONESE', 'Yohann', 'Q3', 'cremonese', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('CRINIER', 'ETIENNE', 'A', 'crinier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('DALVERNY', 'Romain', 'Q4', 'dalverny', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DARPHIN', 'Julien', 'Q4', 'darphin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DECOME ', 'FABRICE', 'A', 'decome ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('DEFAY', 'Yannick', 'Q4', 'defay', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DELACROIX', 'Christophe', 'Q1', 'delacroix', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DESHOULLIERS', 'Jonathan', 'Q1', 'deshoulliers', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DUBOIS', 'LUCIEN', 'A', 'dubois', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('DUFER', 'BENJAMIN', 'A', 'dufer', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('DUGAST', 'Fabien', 'Q3', 'dugast', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('DUMONT', 'GAËTAN', 'A', 'dumont', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('El AMRANI', 'Ayoub', 'Q1', 'el amrani', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('EL MOKADDEM', 'MAROUAN', 'A', 'el mokaddem', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('ESCUDERO', 'Loïc', 'Q4', 'escudero', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ESPOSITO', 'Claudia', 'Q4', 'esposito', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ESTEBE ', 'ANTHONY', 'A', 'estebe ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FAGNOU', 'AURORE', 'A', 'fagnou', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('FAROK', 'MY DRISS', 'A', 'farok', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('FATTAL', 'Thomas', 'Q2', 'fattal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FAURE', 'MATHIEU', 'A', 'faure', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('FAUVEL-JAEGER', 'Thomas', 'Q2', 'fauvel-jaeger', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FIORENTINO', 'PAUL-ALAIN', 'A', 'fiorentino', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('FLOCH', 'SEBASTIEN', 'A', 'floch', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FONQUERNIE', 'YVES', 'A', 'fonquernie', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('FORGO', 'NATHALIE', 'A', 'forgo', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('FOURNIER', 'Fanny', 'Q3', 'fournier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('FROMAGER', 'Arnaud', 'Q3', 'fromager', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GAILLARD', 'Flavien', 'Q3', 'gaillard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GANZA', 'Yvan', 'Q3', 'ganza', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GARCIA', 'GUILLAUME', 'A', 'garcia', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('GELY', 'Mélanie', 'Q4', 'gely', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GENIEYS', 'Irvin', 'Q4', 'genieys', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GIRAUDEAU', 'EDDY', 'A', 'giraudeau', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('GOT', 'ALEXANDRE', 'A', 'got', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('GR?S', 'J?R?MY', 'A', 'gr?s', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('GRAZIOLI', 'ALEXANDRE', 'A', 'grazioli', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('GUARRERA', 'Adrian', 'Q1', 'guarrera', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('GUEDJ', 'BENJAMIN', 'A', 'guedj', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('HADJOUR', 'Rachid', 'Q2', 'hadjour', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('HAENEL', 'CAMILLE', 'A', 'haenel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('HENEL', 'MAÏNA', 'A', 'henel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('HERMET', 'FREDERIC', 'A', 'hermet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('HOLTZ', 'Sven', 'Q3', 'holtz', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('HÖHM', 'JULIEN', 'A', 'höhm', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('JANSSEN', 'Colas', 'Q2', 'janssen', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('JAUMEL', 'TIMOTH?E', 'A', 'jaumel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('KUHN', 'Alexandre', 'Q4', 'kuhn', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LABLANCHY', 'Sébastien', 'Q4', 'lablanchy', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LABORDE', 'Fabien', 'Q1', 'laborde', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LANDA', 'KEVIN', 'A', 'landa', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('LAPIERRE', 'OLIVIER', 'A', 'lapierre', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('LAUZE ', 'Matthieu', 'Q3', 'lauze ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('LE FRIOUX', 'YANN', 'A', 'le frioux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('LEPICARD', 'DAVID', 'A', 'lepicard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('LOUCIF', 'Cyril', 'Q1', 'loucif', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAILLE', 'Nicolas', 'Q1', 'maille', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MANIACI', 'Stéphane', 'Q1', 'maniaci', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MASSE', 'Cédric', 'Q2', 'masse', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MATHERON', 'Charlotte', 'Q2', 'matheron', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MATUSZEK', 'Guillaume', 'Q4', 'matuszek', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAURICE', 'Céline', 'Q1', 'maurice', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MAURY', 'Marc', 'Q1', 'maury', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MELIA', 'Geoffrey', 'Q4', 'melia', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MIRON', 'Jordan', 'Q3', 'miron', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MONNIER', 'Dorian', 'Q1', 'monnier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('MORAINE', 'MAXIME', 'A', 'moraine', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('MORENO', 'PIERRE', 'A', 'moreno', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('MOUMINOUX', 'Guillaume', 'Q2', 'mouminoux', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('NABHEEBUCUS', 'Shehzaad', 'Q1', 'nabheebucus', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('NICOLACCINI', 'Mickaël', 'Q3', 'nicolaccini', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('OLIVERO', 'FLORIAN', 'A', 'olivero', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('OUALI', 'Samy', 'Q4', 'ouali', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PAPIN', 'Geoffrey', 'Q1', 'papin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PARRA', 'Loïc', 'Q1', 'parra', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PASCAL', 'Geoffrey', 'Q4', 'pascal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PASTORELLI', 'GHISLAIN', 'A', 'pastorelli', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('PASTRE', 'Emerentienne', 'Q3', 'pastre', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PEREZ ', 'OLIVIER', 'A', 'perez ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('PERRIN', 'EVIAN', 'A', 'perrin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('PERROT', 'Grégoire', 'Q2', 'perrot', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('POLDER', 'Guillaume', 'Q1', 'polder', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PORTALES', 'Robin', 'Q2', 'portales', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('POURCINE', 'Nicolas', 'Q4', 'pourcine', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PROUVOT', 'Vivien', 'Q4', 'prouvot', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PRUDHOMME', 'Gaël', 'Q2', 'prudhomme', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUECH', 'Robin', 'Q2', 'puech', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUGINIER', 'Julien', 'Q3', 'puginier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUGLIESE', 'Yann', 'Q2', 'pugliese', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('PUIGCERVER', 'ELSA', 'A', 'puigcerver', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('QUETTIER', 'LUCILE', 'A', 'quettier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('RABATEL', 'Camille', 'Q1', 'rabatel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RACLET', 'Yoann', 'Q4', 'raclet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RAMI', 'LEÏLA', 'A', 'rami', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('REBAUBIER', 'WILLIAM', 'A', 'rebaubier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('REGAZZONI', 'ANTHONY', 'A', 'regazzoni', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('ROBERT', 'Kevin', 'Q2', 'robert', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ROLANDO', 'Mathilde', 'Q4', 'rolando', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ROUQUETTE', 'Thibaut', 'Q2', 'rouquette', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('RUBAGOTTI', 'AURELIEN', 'A', 'rubagotti', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('S?N?CAL ', 'GAËL', 'A', 's?n?cal ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('SABACHVILI', 'David', 'Q2', 'sabachvili', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SABATIER', 'PIERRE-ALAIN', 'Q1', 'sabatier', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SALEIL', 'Baptiste', 'Q1', 'saleil', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SANICHANH', 'Morgan', 'Q3', 'sanichanh', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SAUVET', 'Matthieu', 'Q2', 'sauvet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SCHMITT', 'Clément', 'Q3', 'schmitt', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SCHNEIDER', 'AUDREY', 'A', 'schneider', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('SEGUIN', 'TRISTAN', 'A', 'seguin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('SENDNER', 'Damien', 'Q4', 'sendner', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SENDRA', 'Anthony', 'Q4', 'sendra', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('SENN', 'GAELLE', 'A', 'senn', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_PGI'),
('SIMONNET', 'VALERIE', 'A', 'simonnet', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('SIRACUSA', 'LILIAN', 'A', 'siracusa', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('TCHERTCHIAN', 'Guillaume', 'Q2', 'tchertchian', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TEIXEIRA', 'Julien', 'Q3', 'teixeira', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('THIBAUD', 'Henri', 'Q2', 'thibaud', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TIRARD', 'Floriane', 'Q2', 'tirard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TREMESAYGUES', 'Jonathan', 'Q3', 'tremesaygues', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('TUDESQ', 'Philippe', 'Q4', 'tudesq', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VALENTIN', 'FABIEN', 'A', 'valentin', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VAQUER', 'Paul', 'Q4', 'vaquer', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VEDEL', 'CHRISTOPHE', 'A', 'vedel', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VERBAL', 'CHRISTOPHER', 'A', 'verbal', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VERGNES ', 'PASCAL', 'A', 'vergnes ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('VEROUDART', 'LOÏC', 'A', 'veroudart', 'f02368945726d5fc2a14eb576f7276c0', '0', 'AS'),
('VERSTRAETE', 'Didier', 'Q4', 'verstraete', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VICAIRE ', 'HENRI HARALD', 'A', 'vicaire ', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_API'),
('VILACA', 'ADRIEN', 'A', 'vilaca', 'f02368945726d5fc2a14eb576f7276c0', '0', 'LP_ACPI'),
('VILLAGE', 'Benoît', 'Q4', 'village', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('VINARD', 'Florian', 'Q3', 'vinard', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('WEGSCHEIDER', 'Bastien', 'Q1', 'wegscheider', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2'),
('ZIMMERMANN', 'Denis', 'Q3', 'zimmermann', 'f02368945726d5fc2a14eb576f7276c0', '0', 'A2');

-- --------------------------------------------------------

--
-- Structure de la table `indisponibilite`
--

CREATE TABLE IF NOT EXISTS `indisponibilite` (
  `login` varchar(30) NOT NULL,
  `lundi` varchar(50) NOT NULL,
  `mardi` varchar(50) NOT NULL,
  `mercredi` varchar(50) NOT NULL,
  `jeudi` varchar(50) NOT NULL,
  `vendredi` varchar(50) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `indisponibilite`
--

INSERT INTO `indisponibilite` (`login`, `lundi`, `mardi`, `mercredi`, `jeudi`, `vendredi`) VALUES
('salmon', ';', ';3;', ';6;', ';6;', ';');

-- --------------------------------------------------------

--
-- Structure de la table `planning`
--

CREATE TABLE IF NOT EXISTS `planning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lib` text NOT NULL,
  `date_fin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `niveau` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `planning`
--


-- --------------------------------------------------------

--
-- Structure de la table `prof`
--

CREATE TABLE IF NOT EXISTS `prof` (
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `login` varchar(30) NOT NULL,
  `pwd` varchar(80) NOT NULL,
  `droit` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prof`
--

INSERT INTO `prof` (`nom`, `prenom`, `login`, `pwd`, `droit`) VALUES
('ALBERNHE-GIORDAN', 'Hugette', 'albernhe', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BELLAHSENE', 'Zohra', 'bellahsene', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BERLINET', 'Alain', 'berlinet', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BETAILLE', 'Henri', 'betaille', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BONACHE', 'Adrien', 'bonache', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('BOYAT', 'Jeannine', 'boyat', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('CHAPELLIER', 'Philippe', 'chapellier', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('CHIROUZE', 'Anne', 'chirouze', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('COGIS', 'Olivier', 'cogis', '95011b79a4773b86b2c06221f513c6b2', 0),
('COLETTA', 'Rémi', 'coletta', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('CROITORU', 'Madalina', 'croitoru', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('DELPERDANGE', 'Catherine', 'delperdange', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('EGGRICKX', 'Ariel', 'eggrickx', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('GARCIA', 'Francis', 'garcia', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('GENTHIAL', 'Michèle', 'genthial', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('GOUAICH', 'Adbelkader', 'gouaich', 'eb970203d64f5491267a22dfef93037c', 0),
('GUILLEMENET', 'Yoann', 'guillemenet', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('JOANNIDES', 'Marc', 'joannides', '180fd182f9a0742f483619781ccc36c4', 0),
('JOUBERT', 'Alain', 'joubert', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('LACHENY', 'Alain', 'lacheny', '508aabef6aa1190d26b88c7174c9a997', 0),
('LIBRES', 'Aline', 'libres', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('MAHE', 'Serge-André', 'mahe', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('MARIE-JEANNE', 'Alain', 'marie-jeanne', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('MAZARS-CHAPELON', 'Agnès', 'mazars', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('METZ', 'Stéphanie', 'metz', '36f89ebc0885d432ba842f9ca2f41968', 0),
('MICHEL', 'Fabien', 'michel', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('NOUGUIER', 'Bernard', 'nouguier', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('PALAYSI', 'Jérôme', 'palaysi', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('PALLEJA', 'Nathalie', 'pallejaN', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('PALLEJA', 'Xavier', 'pallejaX', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('SABATIER', 'Alain', 'sabatier', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('SALMON', 'Laurence', 'salmon', '21232f297a57a5a743894a0e4a801fc3', 1),
('SIMONET', 'Geneviève', 'simonet', 'd450c5dbcc10db0749277efc32f15f9f', 0),
('VALVERDE', 'Irène', 'valverde', 'b2688812ffc5952c7ad57c95223f023d', 0);

-- --------------------------------------------------------

--
-- Structure de la table `projets`
--

CREATE TABLE IF NOT EXISTS `projets` (
  `id_proj` int(4) NOT NULL AUTO_INCREMENT,
  `tuteur1` varchar(60) NOT NULL,
  `tuteur2` varchar(60) NOT NULL,
  `titre` varchar(100) NOT NULL,
  `binwish` int(1) NOT NULL,
  `binpos` int(1) NOT NULL,
  `description` text NOT NULL,
  `qualif` varchar(100) NOT NULL,
  `dom_appl` text NOT NULL,
  `mat_log` varchar(200) NOT NULL,
  `remarques` text NOT NULL,
  `niveau` varchar(10) NOT NULL,
  `groupe` text NOT NULL,
  PRIMARY KEY (`id_proj`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `projets`
--

INSERT INTO `projets` (`id_proj`, `tuteur1`, `tuteur2`, `titre`, `binwish`, `binpos`, `description`, `qualif`, `dom_appl`, `mat_log`, `remarques`, `niveau`, `groupe`) VALUES
(1, 'salmon', '', 'test', 0, 0, '', '', '', '', 'Aucune', 'A2', '');

-- --------------------------------------------------------

--
-- Structure de la table `soutenance`
--

CREATE TABLE IF NOT EXISTS `soutenance` (
  `id_bin` int(4) NOT NULL,
  `date` int(10) NOT NULL,
  `salle` text NOT NULL,
  `tuteur_comp` varchar(30) NOT NULL,
  PRIMARY KEY (`id_bin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `soutenance`
--

INSERT INTO `soutenance` (`id_bin`, `date`, `salle`, `tuteur_comp`) VALUES
(21, 1263459600, '123', 'berlinet');

-- --------------------------------------------------------

--
-- Structure de la table `wish`
--

CREATE TABLE IF NOT EXISTS `wish` (
  `id_bin` int(4) NOT NULL,
  `wish1` int(4) NOT NULL,
  `wish2` int(4) NOT NULL,
  `wish3` int(4) NOT NULL,
  `wish4` int(4) NOT NULL,
  `wish5` int(4) NOT NULL,
  `niveau` varchar(2) NOT NULL,
  PRIMARY KEY (`id_bin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `wish`
--

INSERT INTO `wish` (`id_bin`, `wish1`, `wish2`, `wish3`, `wish4`, `wish5`, `niveau`) VALUES
(18, 1, 2, 3, 4, 5, 'A2');
